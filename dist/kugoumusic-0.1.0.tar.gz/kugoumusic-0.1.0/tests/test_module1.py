
import kugoumusic
kugoumusic.kugoumusic('download')