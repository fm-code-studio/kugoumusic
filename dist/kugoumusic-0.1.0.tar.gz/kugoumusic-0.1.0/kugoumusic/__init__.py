#kugoumusic/__init__.py
from .kugoumusic import kugoumusic
__all__ = ['kugoumusic']